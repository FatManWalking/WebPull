google.charts.load('current', {
    'packages':['geochart'],
    // Note: you will need to get a mapsApiKey for your project.
    // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
    'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
  });
  google.charts.setOnLoadCallback(drawRegionsMap);

  function drawRegionsMap() {
    var data = google.visualization.arrayToDataTable([
      ['Country', 'Imbissscore'],
      ['Germany', 100],
      ['Netherlands', 1000],
      ['United States', 0],
      ['Brazil', 0],
      ['Canada', 0],
      ['France', 10],
      ['RU', 400],
      ['Namibia', 1000]
    ]);

    var options = {
         // Europe
        colorAxis: {colors: ['#01FDE0', '#23E5CD', '#5A8A84']},
        backgroundColor: '#ffffff',
        datalessRegionColor: '#ffffff',
        defaultColor: '#f5f5f5',
      };

    var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

    chart.draw(data, options);
  }

  function getLogDataKeys()
  {
      $.getJSON("https://webtechlecture.appspot.com/cloudstore/listobjects?owner=GlobalStatics", //mit ...listkeys... holt man nur die Keys nicht ganze Objekte
                
                function(data)//this function is called when the server answers its data
                {
                  if (data.length>0)
                  {
                      $.each(data,
                             function(index,logEntry){//this function is called for each single object in the array named "data" (listobjects and listkeays answer an array, while get does not!)
                                  processLogEntry(logEntry);
                              });
                  }
                }
                  
               ).done(function(){
                  google.charts.setOnLoadCallback(drawStuff);
               });
  }
  
  //each logEntry is processed here
  //process & aggregate the data here
  var dict = {}
  function processLogEntry(aEntry)
  
  {
      //console.log(aEntry)
      //console.log(aEntry["jsonstring"]["app"]);
      if (Object.keys(dict).includes(aEntry["jsonstring"]["app"])){
          dict[aEntry["jsonstring"]["app"]] = dict[aEntry["jsonstring"]["app"]] +1
      }
      else{
          dict[aEntry["jsonstring"]["app"]] = 1
      }
      console.log("UNTEN")

  }