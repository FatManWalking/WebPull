google.charts.load('current', {
    'packages':['geochart'],
    // Note: you will need to get a mapsApiKey for your project.
    // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
    'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
  });
  google.charts.setOnLoadCallback(drawRegionsMap);

  function drawRegionsMap() {
    var data = google.visualization.DataTable()
    data.addColumn("string","Land")
    data.addColumn("number","Imbissscore")

    var options = {
        region: '150', // Europe
        colorAxis: {colors: ['green', 'blue', 'red']},
        backgroundColor: '#ffffff',
        datalessRegionColor: '#ffffff',
        defaultColor: '#f5f5f5',
      };

    var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

    chart.draw(data, options);
  }

  function getLogDataKeys()
  {
      $.getJSON("https://webtechlecture.appspot.com/cloudstore/listobjects?owner=GlobalStatics", //mit ...listkeys... holt man nur die Keys nicht ganze Objekte
                
                function(data)//this function is called when the server answers its data
                {
                  if (data.length>0)
                  {
                      $.each(data,
                             function(index,logEntry){//this function is called for each single object in the array named "data" (listobjects and listkeays answer an array, while get does not!)
                                  processLogEntry(logEntry);
                              });
                  }
                }
                  
               ).done(function(){
                  google.charts.setOnLoadCallback(drawStuff);
               });
  }
  
  //each logEntry is processed here
  //process & aggregate the data here
  var dict = {}
  function processLogEntry(aEntry)
  
  {
      console.log(aEntry)
  }